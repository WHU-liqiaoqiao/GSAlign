# GSAlign_ReID
GSAlign: Geometric and Semantic Alignment Network for Aerial-Ground Person Re-Identification(NuralPS'25)


## Method: SeCap

<img src=".\assets\gsalign.png"/>

### Requirements

#### Prepare environments

Please refer to [INSTALL.md](./INSTALL.md).


```bash
CUDA_VISIBLE_DEVICES=0 python3 tools/train_net.py --config-file ./configs/CARGO/gsalign.yml MODEL.DEVICE "cuda:0" SOLVER.IMS_PER_BATCH 64  
```

Training GSAlign on the CARGO dataset with 4 GPU:

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 python3 tools/train_net.py --config-file ./configs/CARGO/gsalign.yml --num-gpus 4 SOLVER.IMS_PER_BATCH 256
```

Testing GSAlign on the CARGO dataset:

```bash
CUDA_VISIBLE_DEVICES=0 python3 tools/train_net.py --config-file ./configs/CARGO/gsalign.yml --eval-only MODEL.WEIGHTS xxx 
```

